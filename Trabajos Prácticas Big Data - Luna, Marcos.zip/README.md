## Integrantes el grupo

Luna, Leonardo | 21297/2
Marcos, Santiago | 23345/0

## Información Extra

- En el trabajo práctico 2 (Spark SQL) es necesario crear el directorio "datos" y en ella incorporar un archivo datos.txt con el contenido del dataset.

- En el trabajo práctico 3 (Spark Streaming) es necesario poner los (50) archivos del dataset en el directorio "origen_datos", este se crea en la ejecución del script o se puede hacer a mano.
